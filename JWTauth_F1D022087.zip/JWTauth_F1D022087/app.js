require('dotenv').config();
const express = require('express');
const cors = require('cors');
const tilangRoutes = require('./routes/tilangRoutes');
const authRoutes = require('./routes/authRoutes');
const logger = require('./middleware/logger');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use(logger);

app.use('/auth', authRoutes);
app.use('/tilang', tilangRoutes);

app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});