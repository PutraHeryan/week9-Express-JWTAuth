const db = require('../config/database');

class Tilang {
  static async getAll() {
    const [rows] = await db.query('SELECT * FROM tilang');
    return rows;
  }

  static async getById(id) {
    const [rows] = await db.query('SELECT * FROM tilang WHERE id = ?', [id]);
    return rows[0];
  }

  static async create(data) {
    const { nomor_polisi, nama_pelanggar, jenis_pelanggaran, denda, tanggal_tilang } = data;
    const [result] = await db.query(
      'INSERT INTO tilang (nomor_polisi, nama_pelanggar, jenis_pelanggaran, denda, tanggal_tilang) VALUES (?, ?, ?, ?, ?)',
      [nomor_polisi, nama_pelanggar, jenis_pelanggaran, denda, tanggal_tilang]
    );
    return { id: result.insertId, ...data };
  }

  static async update(id, data) {
    const { nomor_polisi, nama_pelanggar, jenis_pelanggaran, denda, tanggal_tilang, status_bayar } = data;
    await db.query(
      'UPDATE tilang SET nomor_polisi = ?, nama_pelanggar = ?, jenis_pelanggaran = ?, denda = ?, tanggal_tilang = ?, status_bayar = ? WHERE id = ?',
      [nomor_polisi, nama_pelanggar, jenis_pelanggaran, denda, tanggal_tilang, status_bayar, id]
    );
    return { id, ...data };
  }

  static async delete(id) {
    await db.query(
      'DELETE FROM tilang WHERE id = ?', [id]
    );
    return {message: 'Data tilang berhasil dihapus'};
  }
}

module.exports = Tilang;