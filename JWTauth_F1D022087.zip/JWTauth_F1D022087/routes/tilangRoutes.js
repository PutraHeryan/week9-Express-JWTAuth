const express = require('express');
const router = express.Router();
const tilangController = require('../controllers/tilangController');
const { validateTilang, handleValidationErrors } = require('../middleware/validator');
const authenticateToken = require('../middleware/authMiddleware');

router.get('/', tilangController.getAllTilang);
router.get('/:id', tilangController.getTilangById);

router.post('/', authenticateToken, validateTilang, handleValidationErrors, tilangController.createTilang);
router.put('/:id', authenticateToken, validateTilang, handleValidationErrors, tilangController.updateTilang);
router.delete('/:id', authenticateToken, tilangController.deleteTilang);

module.exports = router;