const Tilang = require('../models/Tilang');

exports.getAllTilang = async (req, res, next) => {
  try {
    const tilang = await Tilang.getAll();
    res.json(tilang);
  } catch (error) {
    next(error);
  }
};

exports.getTilangById = async (req, res, next) => {
  try {
    const tilang = await Tilang.getById(req.params.id);
    if (!tilang) {
      return res.status(404).json({ message: 'Data tilang tidak ditemukan' });
    }
    res.json(tilang);
  } catch (error) {
    next(error);
  }
};

exports.createTilang = async (req, res, next) => {
  try {
    const newTilang = await Tilang.create(req.body);
    res.status(201).json({ message: 'Data tilang berhasil ditambahkan', data: newTilang });
  } catch (error) {
    next(error);
  }
};

exports.updateTilang = async (req, res, next) => {
  try {
    const updatedTilang = await Tilang.update(req.params.id, req.body);
    if (!updatedTilang) {
      return res.status(404).json({ message: 'Data tilang tidak ditemukan' });
    }
    res.json({ message: 'Data tilang berhasil diperbarui', data: updatedTilang });
  } catch (error) {
    next(error);
  }
};

exports.deleteTilang = async (req, res, next) => {
  try {
    const {id} = req.params;
    await Tilang.delete(id);
    res.json({message: 'Data tilang berhasil dihapus'});
  } catch(error){
    next(error);
  }
};