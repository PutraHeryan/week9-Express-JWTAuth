const { body, validationResult } = require('express-validator');

const validateTilang = [
  body('nomor_polisi').notEmpty().withMessage('Nomor polisi tidak boleh kosong'),
  body('nama_pelanggar').notEmpty().withMessage('Nama pelanggar tidak boleh kosong'),
  body('jenis_pelanggaran').notEmpty().withMessage('Jenis pelanggaran tidak boleh kosong'),
  body('denda').isInt({ min: 0 }).withMessage('Denda harus berupa angka positif'),
  body('tanggal_tilang').isISO8601().toDate().withMessage('Format tanggal salah (YYYY-MM-DD)'),
];

const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};

module.exports = { validateTilang, handleValidationErrors };